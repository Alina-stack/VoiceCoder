# Keep WebView JavaScript interface
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}

# Keep WebView related classes
-keepclassmembers class android.webkit.** { *; }

# Keep app classes
-keep class com.voicecoder.app.** { *; }

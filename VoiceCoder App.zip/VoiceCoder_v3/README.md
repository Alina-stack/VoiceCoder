# VoiceCoder Android App

A native Android wrapper for the VoiceCoder web application at:
**https://voicecoder-production.up.railway.app**

---

## Features
- Full WebView wrapper — 100% of your web app works inside the app
- Microphone permission handled natively (needed for voice coding)
- Swipe-to-refresh to reload the app
- Offline screen with Retry button
- Back-button navigation inside the WebView
- Splash screen
- Dark theme matching VoiceCoder's design

---

## How to Build the APK

### Requirements
- Android Studio Hedgehog (2023.1.1) or newer
- JDK 17 (bundled with Android Studio)
- Internet connection (to download Gradle dependencies)

### Steps

1. **Open the project**
   - Launch Android Studio
   - Click **File → Open**
   - Select this `VoiceCoder` folder
   - Wait for Gradle sync to finish (~2 minutes first time)

2. **Build a debug APK** (quickest, for testing)
   - Menu: **Build → Build Bundle(s) / APK(s) → Build APK(s)**
   - APK location: `app/build/outputs/apk/debug/app-debug.apk`

3. **Build a release APK** (for distribution / Play Store)
   - Menu: **Build → Generate Signed Bundle / APK**
   - Choose **APK**
   - Create or select a keystore (keep it safe — you need it for updates)
   - Select `release` build variant
   - APK location: `app/build/outputs/apk/release/app-release.apk`

4. **Install on your phone**
   - Enable **Developer Options** on your Android phone
   - Enable **USB Debugging**
   - Connect via USB, then in Android Studio click the ▶ Run button

   **Or** transfer the APK file to your phone and tap it to install
   (you may need to allow "Install from unknown sources" in Settings).

---

## Permissions the app requests
| Permission | Why |
|---|---|
| INTERNET | Load the VoiceCoder web app |
| RECORD_AUDIO | Voice coding feature |
| ACCESS_NETWORK_STATE | Show offline screen when disconnected |

---

## Changing the URL
If you ever move off Railway, open:
`app/src/main/java/com/voicecoder/app/MainActivity.kt`

Change line:
```kotlin
private const val URL = "https://voicecoder-production.up.railway.app"
```

---

## Project Structure
```
VoiceCoder/
├── app/
│   ├── src/main/
│   │   ├── AndroidManifest.xml
│   │   ├── java/com/voicecoder/app/
│   │   │   ├── SplashActivity.kt
│   │   │   └── MainActivity.kt
│   │   └── res/
│   │       ├── layout/
│   │       │   ├── activity_splash.xml
│   │       │   └── activity_main.xml
│   │       ├── drawable/
│   │       └── values/
│   └── build.gradle
├── build.gradle
├── settings.gradle
└── gradle.properties
```
